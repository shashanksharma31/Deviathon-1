import { useState } from "react";
import {
  IconAdjustmentsHorizontal,
  IconArrowUpRight,
  IconBookmark,
  IconBus,
  IconCar,
  IconCheck,
  IconClock,
  IconCurrentLocation,
  IconMap2,
  IconMenu2,
  IconMotorbike,
  IconNavigation,
  IconSearch,
  IconShare3,
  IconSparkles,
  IconStarFilled,
  IconWalk,
  IconX,
} from "@tabler/icons-react";
import { APP_TITLE } from "@/lib/app-config";

const categories = ["Explore", "Restaurants", "Cafés", "Petrol", "Hotels"];
const modes = [
  { name: "Drive", time: "38 min", Icon: IconCar },
  { name: "Two-wheeler", time: "36 min", Icon: IconMotorbike },
  { name: "Transit", time: "1 h 12", Icon: IconBus },
  { name: "Walk", time: "4 h 50", Icon: IconWalk },
];

export function meta() {
  return [
    { title: `${APP_TITLE} — Explore nearby` },
    { name: "description", content: "A little intelligence. Every journey." },
  ];
}

export default function HomeRoute() {
  const [category, setCategory] = useState("Explore");
  const [mode, setMode] = useState("Two-wheeler");
  const [saved, setSaved] = useState(false);
  const [navigating, setNavigating] = useState(false);
  const [query, setQuery] = useState("");
  const [notice, setNotice] = useState("");

  function searchPlaces() {
    if (!query.trim()) return;
    setNotice(`Showing the best of ${query.trim()}`);
    window.setTimeout(() => setNotice(""), 2600);
  }

  return (
    <main className="viare-app">
      <aside className="discovery-panel">
        <header className="brand-bar">
          <a className="brand-lockup" href="#home" aria-label="Viare home">
            <span className="brand-mark"><IconMap2 size={20} stroke={1.8} /></span>
            <span className="brand-name">viare<span>.</span></span>
          </a>
          <button className="icon-button mobile-menu" aria-label="Open menu"><IconMenu2 size={20} /></button>
          <span className="live-status"><i /> LIVE ROUTES <b>09:41</b></span>
        </header>

        <div className="panel-content">
          <p className="eyebrow">A LITTLE INTELLIGENCE. EVERY JOURNEY.</p>
          <h1>Discover a little<br />more.</h1>
          <p className="intro-copy">Find your next favorite place, just around the bend.</p>

          <div className="search-box">
            <IconSearch size={19} stroke={1.8} />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              onKeyDown={(event) => event.key === "Enter" && searchPlaces()}
              placeholder="Search a place or ask Viare"
              aria-label="Search a place or ask Viare"
            />
            {query && <button className="search-clear" onClick={() => setQuery("")} aria-label="Clear search"><IconX size={16} /></button>}
            <button className="search-submit" onClick={searchPlaces} aria-label="Search"><IconArrowUpRight size={19} /></button>
          </div>
          <button className="location-shortcut" onClick={() => setNotice("You’re exploring Mathura, Uttar Pradesh")}>
            <span className="location-dot"><IconCurrentLocation size={16} /></span>
            <span><strong>Your location</strong><small>Mathura, Uttar Pradesh</small></span>
            <IconArrowUpRight className="shortcut-arrow" size={16} />
          </button>

          <nav className="category-row" aria-label="Place categories">
            {categories.map((item) => <button key={item} onClick={() => setCategory(item)} className={category === item ? "category-chip active" : "category-chip"}>{item}</button>)}
          </nav>

          <section className="place-summary">
            <div className="section-heading"><span>YOUR NEXT STOP</span><button className="icon-button tune-button" aria-label="Filter places"><IconAdjustmentsHorizontal size={19} /></button></div>
            <div className="place-name-row"><div><h2>Kusum Sarovar</h2><p>Govardhan <span>·</span> Heritage landmark</p></div><button className={saved ? "icon-button save-button saved" : "icon-button save-button"} onClick={() => setSaved(!saved)} aria-label={saved ? "Remove saved place" : "Save place"}>{saved ? <IconCheck size={19} /> : <IconBookmark size={19} />}</button></div>
            <div className="rating-line"><span className="rating-number">4.7</span><span className="stars"><IconStarFilled size={12} /><IconStarFilled size={12} /><IconStarFilled size={12} /><IconStarFilled size={12} /><IconStarFilled size={12} /></span><span className="review-count">(2,231 reviews)</span><span className="open-now"><i /> Open now</span></div>
            <div className="photo-strip" aria-label="Photos of Kusum Sarovar">
              <div className="photo photo-one"><span>THE QUIET GHATS</span></div><div className="photo photo-two"><span>SANDSTONE CHHATRIS</span></div><div className="photo photo-three"><span>STILL WATER</span></div><span className="photo-count">24 photos</span>
            </div>
            <div className="place-description">Sandstone chhatris, quiet ghats and still water. A serene stop on the Govardhan Parikrama trail.</div>
          </section>

          <section className="route-section">
            <div className="section-heading"><span>GETTING THERE</span><button className="text-link" onClick={() => setNotice("Route options updated for current traffic")}>Directions <IconArrowUpRight size={14} /></button></div>
            <div className="mode-tabs" aria-label="Preferred mode">
              {modes.map(({ name, Icon }) => <button key={name} onClick={() => setMode(name)} className={mode === name ? "mode-tab selected" : "mode-tab"}><Icon size={17} stroke={1.7} /><span>{name}</span></button>)}
            </div>
            <div className="route-insight"><span className="insight-icon"><IconSparkles size={15} /></span><p>Save 2 minutes with lighter traffic and easier access through Govardhan’s narrow lanes.</p></div>
            <div className="route-meta"><span><IconClock size={15} />{modes.find((item) => item.name === mode)?.time}</span><span>23 km <i /> via Mathura–Govardhan Rd</span></div>
            <button className={navigating ? "navigate-button navigating" : "navigate-button"} onClick={() => setNavigating(!navigating)}>{navigating ? <IconCheck size={18} /> : <IconNavigation size={18} />} {navigating ? "Navigation started" : "Start navigation"}<IconArrowUpRight className="button-arrow" size={17} /></button>
          </section>
          <footer className="panel-footer"><span>viare maps</span><span>© OpenStreetMap</span><button onClick={() => setNotice("Share link copied")} aria-label="Share this place"><IconShare3 size={16} /></button></footer>
        </div>
      </aside>

      <section className="map-panel" aria-label="Map around Kusum Sarovar, Govardhan">
        <div className="map-texture" />
        <svg className="map-roads" viewBox="0 0 1000 800" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
          <path className="minor-road" d="M-80 148 C120 183 178 86 347 119 S602 196 775 117 1019 134 1100 95" />
          <path className="minor-road" d="M-56 630 C110 584 158 696 314 658 S565 528 701 589 923 691 1090 612" />
          <path className="minor-road" d="M232 -45 C198 112 279 209 231 332 S168 570 245 863" />
          <path className="minor-road" d="M774 -53 C721 101 813 225 771 365 S752 601 868 849" />
          <path className="main-road-shadow" d="M-50 505 C168 476 262 398 399 384 S638 344 745 288 929 192 1075 210" />
          <path className="main-road" d="M-50 505 C168 476 262 398 399 384 S638 344 745 288 929 192 1075 210" />
          <path className="route-shadow" d="M463 730 C470 650 437 588 463 514 S504 415 478 362 479 286 546 234 589 171 571 97" />
          <path className="route-line" d="M463 730 C470 650 437 588 463 514 S504 415 478 362 479 286 546 234 589 171 571 97" />
          <path className="water-line" d="M645 452 C711 422 735 460 798 432 S910 390 1002 430" />
          <path className="water-line" d="M651 472 C713 441 740 481 802 453 S912 410 1001 450" />
        </svg>
        <div className="map-label label-govardhan">GOVARDHAN</div><div className="map-label label-chhatikara">Chhatikara</div><div className="map-label label-radhakund">Radhakund</div><div className="map-label label-deeg">Deeg Road</div>
        <div className="map-label label-cafe"><span>☕</span> Braj café</div><div className="map-label label-petrol"><span>⛽</span> IndianOil</div>
        <div className="map-spot spot-one"><span /></div><div className="map-spot spot-two"><span /></div><div className="map-spot spot-three"><span /></div>
        <div className="map-search"><IconSearch size={18} /><input aria-label="Search map" placeholder="Where do you want to go?" value={query} onChange={(event) => setQuery(event.target.value)} onKeyDown={(event) => event.key === "Enter" && searchPlaces()} /><button aria-label="Search map" onClick={searchPlaces}><IconArrowUpRight size={18} /></button></div>
        <div className="map-tools"><button aria-label="Current location" onClick={() => setNotice("Centered on your location")}><IconCurrentLocation size={20} /></button><button aria-label="Share map" onClick={() => setNotice("Share link copied")}><IconShare3 size={19} /></button></div>
        <div className="map-attribution">Map data © OpenStreetMap contributors</div>
        <article className="arrival-card">
          <div className="arrival-image"><div className="arrival-sun" /><div className="arrival-arch arch-a" /><div className="arrival-arch arch-b" /><div className="arrival-water" /><span className="arrival-tag">GOVARDHAN · GARDEN</span><span className="arrival-live"><i /> LIGHT TRAFFIC</span></div>
          <div className="arrival-content"><div className="arrival-topline"><span className="eyebrow">INTELLIGENT NAVIGATION</span><button className="icon-button" onClick={() => setSaved(!saved)} aria-label={saved ? "Remove saved place" : "Save place"}>{saved ? <IconCheck size={18} /> : <IconBookmark size={18} />}</button></div><h3>Kusum Sarovar</h3><p>Heritage landmark · Mathura–Govardhan Rd</p><div className="arrival-bottom"><span><IconMotorbike size={17} /> {mode} · {modes.find((item) => item.name === mode)?.time}</span><button onClick={() => setMode("Two-wheeler")}>Use mode <IconArrowUpRight size={15} /></button></div></div>
        </article>
        {notice && <div className="toast-note" role="status"><IconCheck size={16} />{notice}<button onClick={() => setNotice("")} aria-label="Dismiss"><IconX size={14} /></button></div>}
        <div className="map-brand"><span className="brand-mark"><IconMap2 size={17} /></span><strong>viare</strong><small>Your world. A wiser way.</small></div>
      </section>
    </main>
  );
}
